<?php 
session_start();
if( !isset($_SESSION['username']) ) {
	header("Location: login.php");
	exit();
}
if ($_SERVER['REQUEST_METHOD'] == "POST") { 
    require_once "conn.php";

    $firstname  = mysqli_real_escape_string($conn, $_POST['firstName']);
    $middlename = mysqli_real_escape_string($conn, $_POST['middleName']);
    $lastname   = mysqli_real_escape_string($conn, $_POST['lastName']);
    $school     = mysqli_real_escape_string($conn, $_POST['school']);

    mysqli_query($conn, "INSERT INTO $tablelog (firstName, middleName, lastName, school) 
        VALUES ('$firstname', '$middlename', '$lastname', '$school')");

    $_SESSION['status'] = "Successfully added!";
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php include("css.php"); ?>
</head>
<body class="bg-light">

    <div class="container mt-5">
        <div class="card shadow-sm mx-auto" style="max-width: 500px;">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="fa-solid fa-user-plus me-2"></i>Add Student</h4>
            </div>
            <div class="card-body">
                <form name="frminfo" action="" method="POST">

                    <div class="mb-3">
                        <label for="firstName" class="form-label">First Name</label>
                        <input type="text" class="form-control" id="firstName" name="firstName" required>
                    </div>

                    <div class="mb-3">
                        <label for="middleName" class="form-label">Middle Name</label>
                        <input type="text" class="form-control" id="middleName" name="middleName" required>
                    </div>

                    <div class="mb-3">
                        <label for="lastName" class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="lastName" name="lastName" required>
                    </div>

                    <div class="mb-3">
                        <label for="school" class="form-label">School</label>
                        <input type="text" class="form-control" id="school" name="school" required>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fa-solid fa-circle-plus me-1"></i>Add
                        </button>
                        <button type="reset" class="btn btn-danger">
                            <i class="fa-solid fa-eraser me-1"></i>Clear
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include("js.php"); ?>
</body>
</html>