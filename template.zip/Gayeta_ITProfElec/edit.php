<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
 <?php include("css.php");?>
<?php 
    session_start();
    if( !isset($_SESSION['username']) ) {
	header("Location: login.php");
	exit();
}
    include("conn.php");
    $id=$_GET['sid'];
    $query=mysqli_query($conn, "SELECT * from $tablelog WHERE id='$id'");
    $row=mysqli_fetch_array($query);

        $id = $row['id'];
        $firstname = $row['firstName'];
        $middlename = $row['middleName'];
        $lastname = $row['lastName'];
        $school = $row['school'];
?>

    <div class = "">
    <form name = "frminfo" action = "" method = "POST">
    <h2 class = "">Update Student</h2>

    <label for = "firstName">First Name: <label>
    <input type="text" class = "" name = "firstName" value="<?php echo $firstname;?>" require> <br>

    <label for = "middleName">Middle Name: <label>
    <input type="text" class = "" name = "middleName" value="<?php echo $middlename;?>" require> <br>

    <label for = "lastName">Last Name: <label>
    <input type="text" class = "" name = "lastName" value="<?php echo $lastname;?>" require> <br>

    <label for = "School">School: <label>
    <input type="text" class = "" name = "school" value="<?php echo $school;?>" require> <br>
    <br>
    <input type="submit" class = "" value="UPDATE"> &nbsp; <input type=  "reset" value =  "CLEAR" class = ""><br>
    </form>
    </div>

    <?php
    if ($_SERVER['REQUEST_METHOD'] == "POST") { 
    require_once "conn.php";
   
    $firstname = $_POST['firstName'];
    $middlename = $_POST['middleName'];
    $lastname = $_POST['lastName'];
    $school = $_POST['school'];

    mysqli_query($conn, "UPDATE $tablelog SET firstName = '$firstname', middleName = '$middlename',
    lastName = '$lastname',school = '$school' WHERE id ='$id'");

    $_SESSION['status'] = "Succesfully Updated!";
    header('location:index.php');
    }
?>
<?php include("js.php");?>

</body>
</html>