<!DOCTYPE html>
<html>
<head>
    <title>SYSTEM LOGIN</title>
    <?php include("css.php"); ?>
</head>
<?php
    session_start();

$error = '';

if (isset($_POST["login"])) {
    require_once "conn.php";
    
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = hash('sha256', $_POST['password']); // You can replace this with password_hash() if upgrading security

    $sql = "SELECT * FROM $tablelogin WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $_SESSION['username'] = $username; // store session
        header('location: index.php');     //redirect to dashboard/home
        exit;
    } else {
        $error = "Invalid username and/or password.";
    }

    mysqli_close($conn);S
}
?>
<body>
<div class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4 shadow" style="min-width: 300px;">
        <h2 class="text-center mb-4">Login Form</h2>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?>
        </div>
        <?php endif; ?>

        <form name="frmLogin" action="" method="POST">
            <div class="mb-3">
                <label>Username:</label>
                <input type="text" class="form-control" name="username" required>
            </div>
            <div class="mb-3">
                <label>Password:</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <div class="text-center">
                <input type="submit" class="btn btn-success w-100" name="login" value="LOGIN">
            </div>
            <div class="text-center">
                Create Account <a href="register.php"> Here </a>
            </div>
        </form>
    </div>
</div>

<?php include("js.php"); ?>
</body>
</html>