<?php
    session_start();
if( !isset($_SESSION['username']) ) {
	header("Location: login.php");
	exit();
}
    $id=$_GET['sid'];
    include('conn.php');
    mysqli_query($conn,"DELETE FROM $tablelog WHERE id= '$id'");
    $_SESSION['status']= " Successfully deleted!";
    header('location:index.php');
    ?>