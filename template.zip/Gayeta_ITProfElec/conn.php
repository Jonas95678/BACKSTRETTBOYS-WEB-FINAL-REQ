<?php
$server = "localhost";
$username = "root";
$password = "";
$dbname = "lesson";
$tablelog = "tddetails";
$tablelogin = "tblusers";

//connection string
$conn = mysqli_connect ("$server", "$username", "$password", "$dbname")
or die ("cannot connect to datase");
if (mysqli_connect_error())
    {
        echo "Failed to connect to MySQL: " , mysqli_connect_error();
    }
?>