<title>SEARCH</title>
<?php include("css.php"); ?>
</head>
<?php

session_start();
if( !isset($_SESSION['username']) ) {
	header("Location: login.php");
	exit();
}
require_once "conn.php";

?>
<body>
<div class="position-absolute top-0 start-50 translate-middle-x">
<form action="search.php" method="post" >
        <table>
            <tr>
                <td width="30%"><a href="index.php" class="link-danger link-offset-2
                    link-underline-opacity-25 link-underline-opacity-100-hover"><i class="
                    fa-solid fa-house">&nbsp;&nbsp;Home</i></a> </td>

                <td width="70%"><input type="text" name="key" maxlength="50" required />
                <input type="submit" name="search" id="search" class="btn btn-danger"
                        value="SEARCH"/>
                </td>
            </tr>
        </table>
</form>


  <table class="table table-striped table-hover mb-0">
                <thead class="table-warning">
                    <tr>
                        <th>Student ID</th>
                        <th>First Name</th>
                        <th>Middle Name</th>
                        <th>Last Name</th>
                        <th>School</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                     <?php
                        if(isset($_POST["search"])){

                        $key = $_POST['key'];

                        $sql = "SELECT * FROM $tablelog WHERE firstname LIKE '%$key%'
                        OR middlename LIKE '%$key%' OR lastname LIKE '%$key%'";
                        $results = mysqli_query($conn,$sql);
                        if ($results){
                        while($row = mysqli_fetch_array($results)){
                        $id = $row['id'];
                        $firstname = $row['firstName'];
                        $middlename = $row['middleName'];
                        $lastname = $row['lastName'];
                        $school = $row['school'];
                    ?>
                    <tr>
                        <td><?php echo $id; ?></td>
                        <td><?php echo $firstname; ?></td>
                        <td><?php echo $middlename; ?></td> 
                        <td><?php echo $lastname; ?></td>
                        <td><?php echo $school; ?></td>
                        <td>
                            <a class="btn btn-sm btn-outline-primary" href="edit.php?sid=<?php echo $id; ?>">
                                <i class="fa-solid fa-pen-to-square"></i> Edit
                            </a>

                            <a class="btn btn-sm btn-outline-danger"
                               onclick="return confirm('Are you sure you want to delete this record?');"
                               href="delete.php?sid=<?php echo $id; ?>">
                                <i class="fa-regular fa-trash-can"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <?php } }}?>
                </tbody>
            </table>