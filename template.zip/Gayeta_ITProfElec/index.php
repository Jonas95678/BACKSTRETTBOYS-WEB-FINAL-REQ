<?php 
session_start();
if( !isset($_SESSION['username']) ) {
	header("Location: login.php");
	exit();
}
include("conn.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sample PHP with MySQL</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php include("css.php"); ?>
</head>
<body class="bg-light">

<div class="container mt-4">

    <?php if (isset($_SESSION['status'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fa-solid fa-circle-check me-2"></i>
            <?php echo $_SESSION['status']; unset($_SESSION['status']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0"><i class="fa-solid fa-users me-2"></i>Student List</h4>
        <a href="search.php" class="btn btn-primary">
            <i class="fa-regular fa-address-book me-1"></i>Search
        </a>
        <a href="add.php" class="btn btn-primary">
            <i class="fa-regular fa-address-book me-1"></i>Add Student
        </a>
        <a href="logout.php" class="btn btn-primary">
            <i class="fa-regular fa-address-book me-1"></i>Logout
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-warning">
                    <tr>
                        <th>Student ID</th>
                        <th>First Name</th>
                        <th>Middle Name</th>
                        <th>Last Name</th>
                        <th>School</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = mysqli_query($conn, "SELECT * FROM $tablelog");

                    if (mysqli_num_rows($query) > 0):
                        while ($row = mysqli_fetch_array($query)):
                            $id         = $row['id'];
                            $firstname  = $row['firstName'];
                            $middlename = $row['middleName'];
                            $lastname   = $row['lastName'];
                            $school     = $row['school'];
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($id); ?></td>
                        <td><?php echo htmlspecialchars($firstname); ?></td>
                        <td><?php echo htmlspecialchars($middlename); ?></td>
                        <td><?php echo htmlspecialchars($lastname); ?></td>
                        <td><?php echo htmlspecialchars($school); ?></td>
                        <td class="text-center">
                            <a href="edit.php?sid=<?php echo $id; ?>" class="btn btn-sm btn-warning me-1">
                                <i class="fa-solid fa-pen-to-square"></i> Edit
                            </a>
                            <a href="delete.php?sid=<?php echo $id; ?>"
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Are you sure you want to delete this record?');">
                                <i class="fa-regular fa-trash-can"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <?php
                        endwhile;
                    else:
                    ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="fa-solid fa-database me-2"></i>No records found.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php include("js.php"); ?>
</body>
</html>